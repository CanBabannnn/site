<template>
<div class="rounded-lg mt-32">
    <div class="relative">
        <div class="flex flex-col lg:flex-row justify-between w-full items-center h-full">
            <div class="flex flex-col lg:justify-start justify-center items-center lg:items-start mt-5 lg:mt-0 w-full">
                <div class="flex items-center">
                    <p class="flex items-center text-4xl font-bold">Hi, I'm mishu</p></div>
                <p class="font-light max-w-xl text-md mt-3">Hello, I'm <span onmouseenter="whoIsMishu()" id="whoIsMishu">Mishu</span>. I'm a high school student and I've been coding for about 2-3 years.</p>
                <span class="ml-2 status-bg dc-bg px-2 py-1 font-normal rounded-md text-sm" style='margin:5px;'><i class="fa fa-circle text-offline mr-2"></i>Loading</span>
                <span class="ml-2 activity dc-bg px-2 py-1 font-normal rounded-md text-sm" style='margin:5px;'><i class="fa-solid fa-gamepad text-offline mr-2"></i>Loading</span>
                <span class="ml-2 listening-activity dc-bg px-2 py-1 font-normal rounded-md text-sm" style='margin:5px;'><i class="fa-brands fa-spotify text-offline mr-2"></i>Loading</span>
                <span class="modalIcon ml-2 discord-lg dc-bg px-2 py-1 font-normal rounded-md text-sm discord_profile_viewer" style="cursor:pointer;margin:5px;"><span class="ml-2 text-offline px-2 py-1 font-normal rounded-md text-sm"><i class="fa-brands fa-discord text-color mr-2"></i></span></span>
            </div>
            <div class="m-2">
            <div class="dc-bg discord-div w-[480px] h-28 flex justify-between items-center px-4 rounded-b-lg">
                <div class="flex"><img width="78" draggable="false" class="rounded-xl icon" src="https://cdn.mishudev.xyz/t/fbda846d-2b29-419c-9bd5-0d2f25456751.jpg" style="border-radius:25px;">
                    <div class="ml-3 mt-1">
                        <h1 class="font-bold name text-[25px]">Mishu Base</h1>
                        <div><i class="fa fa-circle text-online text-xs mr-1 relative"></i><span class="text-xs members font-medium">0 Online</span><i class="fa fa-circle ml-3 text-offline text-xs mr-1 relative"></i><span class="text-xs topmembers font-medium">0 Members</span></div>
                    </div>
                </div>
                <button class="bg-[#2D7D46] invite text-white font-medium px-10 hover:bg-[#27693b] transition-all py-2 rounded" style="cursor:pointer;">Join</button>
            </div>
            </div>
        </div>
    </div>
</div>
</template>
