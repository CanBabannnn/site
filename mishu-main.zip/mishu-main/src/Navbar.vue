<template>
    <div class="navbar sticky-nav mt-2">
        <a href="#" style="font-size:25px;">mishudev.xyz</a>
	<button id="switch-mode-btn" class="navbar-btns switch-mode-btn transition-shadow hover:shadow-md mr-1"><i class="fa-solid fa-moon"></i></button>
    </div>
</template>
