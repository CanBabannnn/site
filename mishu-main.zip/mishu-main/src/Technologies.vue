<template>
    <div class="py-20">
        <p class="text-[50px] font-bold">Frontend Development</p>
        <div class="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 w-full gap-2 items-center mt-2">
            <div class="hover:scale-[1.02] hover:-translate-y-1 cursor-pointer techs py-3 px-6 text-lg hover:bg-[#1b1b20]/50 transition-all duration-200 rounded-lg w-full">
                <div class="flex justify-between items-center w-full">
                    <div class="flex justify-center items-center h-[26px]"><img draggable="false" src="/assets/img/html.png" class="rounded-md" width="32" height="32"></div>
                    <p class="text-md font-semibold">Html5</p>
                </div>
            </div>
            <div class="hover:scale-[1.02] hover:-translate-y-1 cursor-pointer techs py-3 px-6 text-lg hover:bg-[#1b1b20]/50 transition-all duration-200 rounded-lg w-full">
                <div class="flex justify-between items-center w-full">
                    <div class="flex justify-center items-center h-[26px]"><img draggable="false" src="/assets/img/css.png" class="rounded-md" width="32" height="32"></div>
                    <p class="text-md font-semibold">Css3</p>
                </div>
            </div>
            <div class="hover:scale-[1.02] hover:-translate-y-1 cursor-pointer techs py-3 px-6 text-lg hover:bg-[#1b1b20]/50 transition-all duration-200 rounded-lg w-full">
                <div class="flex justify-between items-center w-full">
                    <div class="flex justify-center items-center h-[26px]"><img draggable="false" src="/assets/img/vue.png" class="rounded-md" width="32" height="32"></div>
                    <p class="text-md font-semibold">Vue</p>
                </div>
            </div>
            <div class="hover:scale-[1.02] hover:-translate-y-1 cursor-pointer techs py-3 px-6 text-lg hover:bg-[#1b1b20]/50 transition-all duration-200 rounded-lg w-full">
                <div class="flex justify-between items-center w-full">
                    <div class="flex justify-center items-center h-[26px]"><img draggable="false" src="/assets/img/react.svg" class="rounded-md" width="32" height="32"></div>
                    <p class="text-md font-semibold">React</p>
                </div>
            </div>
            <div class="hover:scale-[1.02] hover:-translate-y-1 cursor-pointer techs py-3 px-6 text-lg hover:bg-[#1b1b20]/50 transition-all duration-200 rounded-lg w-full">
                <div class="flex justify-between items-center w-full">
                    <div class="flex justify-center items-center h-[26px]"><img draggable="false" src="/assets/img/svelte.png" class="rounded-md" width="32" height="32"></div>
                    <p class="text-md font-semibold">Svelte</p>
                </div>
            </div>
            <div class="hover:scale-[1.02] hover:-translate-y-1 cursor-pointer techs py-3 px-6 text-lg hover:bg-[#1b1b20]/50 transition-all duration-200 rounded-lg w-full">
                <div class="flex justify-between items-center w-full">
                    <div class="flex justify-center items-center h-[26px]"><img draggable="false" src="/assets/img/bootstrap.svg" class="rounded-md" width="32" height="32"></div>
                    <p class="text-md font-semibold">Bootstrap</p>
                </div>
            </div>
            <div class="hover:scale-[1.02] hover:-translate-y-1 cursor-pointer techs py-3 px-6 text-lg hover:bg-[#1b1b20]/50 transition-all duration-200 rounded-lg w-full">
                <div class="flex justify-between items-center w-full">
                    <div class="flex justify-center items-center h-[26px]"><img draggable="false" src="/assets/img/tailwindLogo.png" class="rounded-md" width="32" height="32"></div>
                    <p class="text-md font-semibold">Tailwind</p>
                </div>
            </div>
        </div>

        <p class="text-[50px] font-bold textRight" style="padding-top:28px;">Backend Development</p>
        <div class="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 w-full gap-2 items-center mt-2">
            <div class="hover:scale-[1.02] hover:-translate-y-1 cursor-pointer techs py-3 px-6 text-lg hover:bg-[#1b1b20]/50 transition-all duration-200 rounded-lg w-full">
                <div class="flex justify-between items-center w-full">
                    <div class="flex justify-center items-center h-[26px]"><img draggable="false" src="/assets/img/nodejs.png" class="rounded-md" width="32" height="32"></div>
                    <p class="text-md font-semibold">Node.js</p>
                </div>
            </div>
            <div class="hover:scale-[1.02] hover:-translate-y-1 cursor-pointer techs py-3 px-6 text-lg hover:bg-[#1b1b20]/50 transition-all duration-200 rounded-lg w-full">
                <div class="flex justify-between items-center w-full">
                    <div class="flex justify-center items-center h-[26px]"><img draggable="false" src="/assets/img/express.svg" class="rounded-md" width="32" height="32"></div>
                    <p class="text-md font-semibold">Express</p>
                </div>
            </div>
            <div class="hover:scale-[1.02] hover:-translate-y-1 cursor-pointer techs py-3 px-6 text-lg hover:bg-[#1b1b20]/50 transition-all duration-200 rounded-lg w-full">
                <div class="flex justify-between items-center w-full">
                    <div class="flex justify-center items-center h-[26px]"><img draggable="false" src="/assets/img/ngnix.svg" class="rounded-md" width="32" height="32"></div>
                    <p class="text-md font-semibold">Ngnix</p>
                </div>
            </div>
        </div>

        <p class="text-[50px] font-bold" style="padding-top:28px;">Database</p>
        <div class="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 w-full gap-2 items-center mt-2">
            <div class="hover:scale-[1.02] hover:-translate-y-1 cursor-pointer techs py-3 px-6 text-lg hover:bg-[#1b1b20]/50 transition-all duration-200 rounded-lg w-full">
                <div class="flex justify-between items-center w-full">
                    <div class="flex justify-center items-center h-[26px]"><img draggable="false" src="/assets/img/mysql.svg" class="rounded-md" width="32" height="32"></div>
                    <p class="text-md font-semibold">Mysql</p>
                </div>
            </div>
            <div class="hover:scale-[1.02] hover:-translate-y-1 cursor-pointer techs py-3 px-6 text-lg hover:bg-[#1b1b20]/50 transition-all duration-200 rounded-lg w-full">
                <div class="flex justify-between items-center w-full">
                    <div class="flex justify-center items-center h-[26px]"><img draggable="false" src="/assets/img/mongodb.png" class="rounded-md" width="32" height="32"></div>
                    <p class="text-md font-semibold">Mongo</p>
                </div>
            </div>
            <div class="hover:scale-[1.02] hover:-translate-y-1 cursor-pointer techs py-3 px-6 text-lg hover:bg-[#1b1b20]/50 transition-all duration-200 rounded-lg w-full">
                <div class="flex justify-between items-center w-full">
                    <div class="flex justify-center items-center h-[26px]"><img draggable="false" src="/assets/img/postgre.svg" class="rounded-md" width="32" height="32"></div>
                    <p class="text-md font-semibold">Postgre</p>
                </div>
            </div>
            <div class="hover:scale-[1.02] hover:-translate-y-1 cursor-pointer techs py-3 px-6 text-lg hover:bg-[#1b1b20]/50 transition-all duration-200 rounded-lg w-full">
                <div class="flex justify-between items-center w-full">
                    <div class="flex justify-center items-center h-[26px]"><img draggable="false" src="/assets/img/sqlite.svg" class="rounded-md" width="32" height="32"></div>
                    <p class="text-md font-semibold">Sqlite</p>
                </div>
            </div>
        </div>

        <p class="text-[50px] font-bold textRight" style="padding-top:28px;">Framework</p>
        <div class="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 w-full gap-2 items-center mt-2">
            <div class="hover:scale-[1.02] hover:-translate-y-1 cursor-pointer techs py-3 px-6 text-lg hover:bg-[#1b1b20]/50 transition-all duration-200 rounded-lg w-full">
                <div class="flex justify-between items-center w-full">
                    <div class="flex justify-center items-center h-[26px]"><img draggable="false" src="/assets/img/django.svg" class="rounded-md" width="32" height="32"></div>
                    <p class="text-md font-semibold">Django</p>
                </div>
            </div>
            <div class="hover:scale-[1.02] hover:-translate-y-1 cursor-pointer techs py-3 px-6 text-lg hover:bg-[#1b1b20]/50 transition-all duration-200 rounded-lg w-full">
                <div class="flex justify-between items-center w-full">
                    <div class="flex justify-center items-center h-[26px]"><img draggable="false" src="/assets/img/dotnet.svg" class="rounded-md" width="32" height="32"></div>
                    <p class="text-md font-semibold">Dot net</p>
                </div>
            </div>
            <div class="hover:scale-[1.02] hover:-translate-y-1 cursor-pointer techs py-3 px-6 text-lg hover:bg-[#1b1b20]/50 transition-all duration-200 rounded-lg w-full">
                <div class="flex justify-between items-center w-full">
                    <div class="flex justify-center items-center h-[26px]"><img draggable="false" src="/assets/img/laravel.svg" class="rounded-md" width="32" height="32"></div>
                    <p class="text-md font-semibold">Laravel</p>
                </div>
            </div>
            <div class="hover:scale-[1.02] hover:-translate-y-1 cursor-pointer techs py-3 px-6 text-lg hover:bg-[#1b1b20]/50 transition-all duration-200 rounded-lg w-full">
                <div class="flex justify-between items-center w-full">
                    <div class="flex justify-center items-center h-[26px]"><img draggable="false" src="/assets/img/flask.svg" class="rounded-md" width="32" height="32"></div>
                    <p class="text-md font-semibold">Flask</p>
                </div>
            </div>
        </div>
    </div>

    
</template>