# Changelog
Added social network links to Discord profile modal.
----------------------------------------------------
# Installation
`git clone https://github.com/mishuw/mishuw.github.io`<br>
`cd mishuw.github.io`<br>
`npm install`<br>
`npm start`
