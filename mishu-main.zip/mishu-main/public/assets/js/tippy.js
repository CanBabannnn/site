tippy('.discord-lg', {
    content: '<span class="keyboardKey">shift</span>&nbsp;<i class="fas fa-plus"></i>&nbsp;&nbsp;<span class="keyboardKey">k</span>',
    animation: 'scale',
    placement: 'top',
    theme: 'ws',
    inertia: true,
    interactive: false,
    allowHTML: true
});
tippy('.contact_modal_viewer', {
    content: '<span class="keyboardKey">shift</span>&nbsp;<i class="fas fa-plus"></i>&nbsp;&nbsp;<span class="keyboardKey">c</span>',
    animation: 'scale',
    placement: 'top',
    theme: 'ws',
    inertia: true,
    interactive: false,
    allowHTML: true
});
